package com.cognizant.hotelmanagement.service;

import com.cognizant.hotelmanagement.model.Room;

public interface RoomService {

	Room findByrno(Integer rno);

}
