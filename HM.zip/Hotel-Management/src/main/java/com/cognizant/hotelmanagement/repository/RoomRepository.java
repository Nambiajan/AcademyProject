package com.cognizant.hotelmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.hotelmanagement.model.Room;

public interface RoomRepository extends JpaRepository<Room,Integer> {
        Room findByrno(Integer rno);
}
