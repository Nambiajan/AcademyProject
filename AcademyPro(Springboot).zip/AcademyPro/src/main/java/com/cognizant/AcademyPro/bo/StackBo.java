package com.cognizant.AcademyPro.bo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.AcademyPro.Dao.StackDao;
import com.cognizant.AcademyPro.entity.Objective;
import com.cognizant.AcademyPro.entity.Stack;
import com.cognizant.AcademyPro.model.Objective_model;
import com.cognizant.AcademyPro.model.Stack_model;


public interface StackBo {
	
	public void addStack(Stack_model s);

	public List<Stack_model> showStack();

	public void removeStack(Stack_model sm);

	public void updateStack(Stack_model sm);
}
