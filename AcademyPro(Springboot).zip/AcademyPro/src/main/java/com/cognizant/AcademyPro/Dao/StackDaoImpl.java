package com.cognizant.AcademyPro.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import com.cognizant.AcademyPro.entity.Stack;
import com.cognizant.AcademyPro.repository.StackRepository;
@Service
public class StackDaoImpl implements StackDao{

	@Autowired
	private StackRepository stackrepository;
	@Override
	public void saveStack(Stack stack) {
		// TODO Auto-generated method stub
		stackrepository.save(stack);
	}

	@Override
	public List<Stack> findAll() {
		// TODO Auto-generated method stub
		return stackrepository.findAll();
	}

	@Override
	public void deleteStack(Integer id) {
		// TODO Auto-generated method stub
		stackrepository.deleteById(id);
		
	}

	@Override
	public void updateStack(Stack stack) {
		// TODO Auto-generated method stub
		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		Stack s=stackrepository.findById(stack.getId()).get();
		System.out.println(s.getName());
		s.setName(stack.getName());
		s.setId(stack.getId());
		System.out.println(s.getName());
		stackrepository.save(s);
		
	}

}
