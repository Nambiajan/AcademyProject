package com.cognizant.AcademyPro.bo;

import java.util.ArrayList;
import java.util.List;

import com.cognizant.AcademyPro.model.User_model;
import com.cognizant.academy.dao.UserDao;
import com.cognizant.academy.entity.User;

public class UserBo {

	public List<User_model> showUsers() {
		// TODO Auto-generated method stub
		List<User_model> uml = new ArrayList<User_model>();
		
		List<User> ul = new ArrayList<User>();
		
		UserDao ud = new UserDao();
		ul = ud.showUsers();
		
		for(User u :ul)
		{
			User_model um = new User_model();
			um.setId(u.getId());
			um.setName(u.getName());
			um.setPassword(u.getPassword());
			um.setRole(u.getRole());
			um.setStatus(u.getStatus());
			um.setUsername(u.getUsername());
			
			uml.add(um);
		}
		
		return uml;
	}

	/*public List<User_model> searchUsers(User_model um) {
		// TODO Auto-generated method stub
		List<User_model> uml = new ArrayList<User_model>();
		List<User> ul = new ArrayList<User>();
		User u = new User();
		u.setName(um.getName());
		
		UserDao ud = new UserDao();
		
		ul = ud.searchUsers(u);
		
		for(User u1 :ul)
		{
			User_model um1 = new User_model();
			um1.setId(u1.getId());
			um1.setName(u1.getName());
			um1.setPassword(u1.getPassword());
			um1.setRole(u1.getRole());
			um1.setStatus(u1.getStatus());
			um1.setUsername(u1.getUsername());
			
			uml.add(um1);
		}
		
		
		return uml;
		
		
	}*/

	public List<User_model> filterUsers(User_model um) {
		// TODO Auto-generated method stub
		List<User_model> uml = new ArrayList<User_model>();
		List<User> ul = new ArrayList<User>();
		User u = new User();
		u.setStatus(um.getStatus());
		
         UserDao ud = new UserDao();
		
		ul = ud.filterUsers(u);
		
		for(User u1 :ul)
		{
			User_model um1 = new User_model();
			um1.setId(u1.getId());
			um1.setName(u1.getName());
			um1.setPassword(u1.getPassword());
			um1.setRole(u1.getRole());
			um1.setStatus(u1.getStatus());
			um1.setUsername(u1.getUsername());
			
			uml.add(um1);
		}
		
		
		return uml;
		
	}

}
