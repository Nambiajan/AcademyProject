export class Article {
   constructor(public articleId: string, public title: string, public category: string) { 
   }
} 