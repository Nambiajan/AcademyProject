package com.cognizant.hotelmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.hotelmanagement.model.Room;
import com.cognizant.hotelmanagement.repository.RoomRepository;

@Service
public class RoomServiceImpl implements RoomService {

	@Autowired
	private RoomRepository roomrepository;
	
	@Override
	public Room findByrno(Integer rno) {
		// TODO Auto-generated method stub
		return roomrepository.findByrno(rno);
	}

	@Override
	public Room findById(Integer rid) {
		// TODO Auto-generated method stub
		return roomrepository.findById(rid).get();
	}

}
