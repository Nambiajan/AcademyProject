package com.cognizant.hotelmanagement.service;

import com.cognizant.hotelmanagement.model.RoomBookings;

public interface RoomBookingService {

	 RoomBookings findById(Integer id);
	 
	 void updateRoomBooking(Integer rbid);
}
