package com.cognizant.hotelmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.hotelmanagement.model.RoomBookings;
import com.cognizant.hotelmanagement.repository.RoomBookingRepository;

@Service
public class RoomBookingServiceImpl  implements RoomBookingService{

	@Autowired
	private RoomBookingRepository roombookingrepository;
	@Override
	public RoomBookings findById(Integer Id) {
		// TODO Auto-generated method stub
		return roombookingrepository.findById(Id).get();
	}
	@Override
	public void updateRoomBooking(Integer rbid) {
		// TODO Auto-generated method stub
		RoomBookings rbs =roombookingrepository.findById(rbid).get();
		if(rbs.getStatus().equals("Available"))
		{
			rbs.setStatus("Booked");
			rbs.setColor("#FA8072");
		}
		else
		{
			rbs.setStatus("Available");
			rbs.setColor("#B1FF83");
			
		}
		roombookingrepository.save(rbs);
		
	}

}
