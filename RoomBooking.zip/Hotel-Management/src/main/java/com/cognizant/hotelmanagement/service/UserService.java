package com.cognizant.hotelmanagement.service;

import com.cognizant.hotelmanagement.model.User;

public interface UserService {
    void save(User user);

    User findByUsername(String username);
}
