package com.cognizant.hotelmanagement.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class RoomBookings {
    @Id
    @GeneratedValue
	private Integer rbid;
    
    private Date rbdate;
    
    @ManyToOne
    @JoinColumn(name="rid")
    private Room room;
    
   
	public Integer getRbid() {
		return rbid;
	}


	public void setRbid(Integer rbid) {
		this.rbid = rbid;
	}


	public Date getRbdate() {
		return rbdate;
	}


	public void setRbdate(Date rbdate) {
		this.rbdate = rbdate;
	}


	public Room getRoom() {
		return room;
	}


	public void setRoom(Room room) {
		this.room = room;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	private String status;
	
	private String color;
    
}
