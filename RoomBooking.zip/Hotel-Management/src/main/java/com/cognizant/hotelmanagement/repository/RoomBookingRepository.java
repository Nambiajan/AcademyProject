package com.cognizant.hotelmanagement.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.hotelmanagement.model.RoomBookings;

public interface RoomBookingRepository extends JpaRepository<RoomBookings,Integer>{

	

}
