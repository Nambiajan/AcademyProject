package com.cognizant.hotelmanagement.model;

import java.util.List;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Room {
	
	@Id
	@GeneratedValue
	private Integer rid;
	
	private Integer rno;
    
	public Integer getRid() {
		return rid;
	}

	public void setRid(Integer rid) {
		this.rid = rid;
	}

	public List<RoomBookings> getRoomBookings() {
		return RoomBookings;
	}

	public void setRoomBookings(List<RoomBookings> roomBookings) {
		RoomBookings = roomBookings;
	}

	public Integer getRno() {
		return rno;
	}

	public void setRno(Integer rno) {
		this.rno = rno;
	}

	@OneToMany(cascade=CascadeType.ALL,mappedBy="room",fetch=FetchType.EAGER)
	private List<RoomBookings> RoomBookings;

	
	

}
