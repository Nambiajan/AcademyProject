package com.cognizant.hotelmanagement.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.hotelmanagement.model.Room;
import com.cognizant.hotelmanagement.service.RoomBookingService;
import com.cognizant.hotelmanagement.service.RoomService;

@Controller
public class BookingController {
    
	@Autowired
	private RoomBookingService roombookingservice;
	@Autowired
	private RoomService roomservice;
	@PostMapping("/bookingDetails")
	String showDetails(@RequestParam String r_no,Model model)
	{
		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		System.out.println(r_no);
		Room room=roomservice.findByrno(Integer.parseInt(r_no));
		System.out.println(room.getRid());
		System.out.println(room.getRoomBookings().size());
		model.addAttribute("List",room);
		
		return "welcome";
	}
	
	@PostMapping("/changeDetails")
	String changeDetails(@RequestParam String rid, @RequestParam String rbid, Model model)
	{
		roombookingservice.updateRoomBooking(Integer.parseInt(rbid));
		
		Room room=roomservice.findById(Integer.parseInt(rid));
		model.addAttribute("List",room);
		
		return "welcome";
		
	}
}
