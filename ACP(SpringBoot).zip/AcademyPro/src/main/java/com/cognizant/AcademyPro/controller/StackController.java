package com.cognizant.AcademyPro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestParam;


import com.cognizant.AcademyPro.bo.StackBo;

import com.cognizant.AcademyPro.model.Stack_model;

@Controller
public class StackController {

	 @Autowired
	 private Stack_model stackmodel;
	 @Autowired
	 private StackBo stackservice;
	 @GetMapping("/ShowStacks")
	 String showStacks(Model model)
	 {
		 model.addAttribute("List",stackservice.showStack());
		 
		return "Stack";
		 
	 }
	 
	 @PostMapping("/addStack")
	 String addStack(@RequestParam("name") String name, Model model)
	 {
		 
		 stackmodel.setName(name);
		 stackservice.addStack(stackmodel);
		 return showStacks(model);
	 }
	 @PostMapping("/rmvStack")
	 String rmv(@RequestParam("id") String id,Model model)
	 {
		stackmodel.setId(Integer.parseInt(id));
		stackservice.removeStack(stackmodel);
		return showStacks(model);
	 }
	 
	 @PostMapping("/updtStack")
	 String updt(@RequestParam("id") String id,@RequestParam("sname") String name,Model model)
	 {
		 stackmodel.setId(Integer.parseInt(id));
		 stackmodel.setName(name);
		 stackservice.updateStack(stackmodel);
		 return showStacks(model);
	 }
	 
}
