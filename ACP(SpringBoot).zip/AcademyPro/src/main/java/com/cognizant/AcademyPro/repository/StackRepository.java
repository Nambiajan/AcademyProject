package com.cognizant.AcademyPro.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.AcademyPro.entity.Stack;

public interface StackRepository extends JpaRepository<Stack, Integer>{

}
