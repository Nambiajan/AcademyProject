package com.cognizant.AcademyPro.bo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.AcademyPro.Dao.StackDao;
import com.cognizant.AcademyPro.model.Stack_model;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.AcademyPro.Dao.StackDao;
import com.cognizant.AcademyPro.entity.Objective;
import com.cognizant.AcademyPro.entity.Stack;
import com.cognizant.AcademyPro.model.Objective_model;

@Service
public class StackBoImpl implements StackBo {

		 @Autowired
		 private StackDao stackdao;
		public void addStack(Stack_model s)
		{
			
			Stack stack = new Stack();
			
			stack.setName(s.getName());
			
			stackdao.saveStack(stack);
		
		}

		public List<Stack_model> showStack() {
			// TODO Auto-generated method stub
			
			List<Stack> stack = new ArrayList<Stack>();
			List<Stack_model> s = new ArrayList<Stack_model>();
			

			 stack = stackdao.findAll();
			 
			 for(Stack sl:stack)
			 {
			    Stack_model sm = new Stack_model();
			    sm.setId(sl.getId());
			    sm.setName(sl.getName());
			    List<Objective_model> obml=new ArrayList<Objective_model>();
			    for(Objective ob :sl.getObjective())
			    {
			    	Objective_model obm = new Objective_model();
			    	obm.setId(ob.getId());
			    	obm.setDescription(ob.getDescription());
			    	obm.setLevel(ob.getLevel());
			    	obm.setName(ob.getName());
			    	obml.add(obm);
			    	
			    }
			    sm.setObjective(obml);
			    sm.setCount(obml.size());
			    for(Objective_model ob:obml)
			    {
			    	ob.setStack(sm);
			    }
			    s.add(sm);
			 }
			
			return s;
		}

		public void removeStack(Stack_model sm) {
			// TODO Auto-generated method stub
			Stack stack = new Stack();
			stack.setId(sm.getId());
		
			stackdao.deleteStack(stack.getId());
		}

		public void updateStack(Stack_model sm) {
			// TODO Auto-generated method stub
			Stack stack = new Stack();
			stack.setId(sm.getId());
			stack.setName(sm.getName());
		    stackdao.updateStack(stack);
		}

}
