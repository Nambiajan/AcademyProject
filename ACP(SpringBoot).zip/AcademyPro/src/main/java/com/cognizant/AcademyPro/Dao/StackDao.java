package com.cognizant.AcademyPro.Dao;

import java.util.List;

import com.cognizant.AcademyPro.entity.Stack;

public interface StackDao {

	 void saveStack(Stack stack);
	 
	 List<Stack> findAll();
	 
	 void deleteStack(Integer id);
	 
	 void updateStack(Stack stack);
}
